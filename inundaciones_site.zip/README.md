
# Inundaciones - Concientización

Este sitio web busca concientizar sobre las inundaciones y el impacto de la contaminación en el clima.

## Cómo publicarlo en GitHub Pages

1. Crea un repositorio llamado **inundaciones** en GitHub.
2. Sube los archivos de este ZIP al repositorio.
3. Ve a **Settings > Pages**.
4. En 'Source', selecciona **Deploy from branch** y elige `main` o `master`, carpeta `/root`.
5. Guarda y obtendrás un enlace como:
   `https://tuusuario.github.io/inundaciones`

